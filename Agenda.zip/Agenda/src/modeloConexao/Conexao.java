/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloConexao;

import java.sql.*;
import javax.swing.*;

public class Conexao {

    final private String driver = "org.gjt.mm.mysql.Driver";
    final private String url = "jdbc:mysql://localhost:3306/bd_agenda?useSSL=false";
    final private String usuario = "root";
    final private String senha = "14725800";
    public Connection conexao;
    public Statement statement;
    public ResultSet resultset;

    public boolean conecta() {
        boolean result = true;
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, usuario, senha);
            //JOptionPane.showMessageDialog(null, "conectou!");
        } catch (ClassNotFoundException Driver) {
            JOptionPane.showMessageDialog(null, "Driver nao encontrado!" + Driver);
            result = false;
        } catch (SQLException Fonte) {
            JOptionPane.showMessageDialog(null, "Deu erro na conexao com a fonte de dados!" + Fonte);
            result = false;
        }
        return result;

    }

    public void desconecta() {
        boolean result = true;
        try {
            conexao.close();
            //JOptionPane.showMessageDialog(null, "Banco desconectado!");
        } catch (SQLException erroSQL) {
            JOptionPane.showMessageDialog(null, "Não foi possivel desconectar o Banco de Dados" + erroSQL);
            result = false;
        }
    }

    public void executeSQL(String sql) {
        try {
            
            //statement = conexao.createStatement();
            statement = conexao.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            resultset = statement.executeQuery(sql);
            
        } catch (SQLException sqlex) {
            
            JOptionPane.showMessageDialog(null, "Não foi possivel executar o comando SQL" + sqlex + " O SQL passado foi" + sql);

        }


    }

}