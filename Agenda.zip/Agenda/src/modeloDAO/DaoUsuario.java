/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDAO;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modeloBeans.ModelBeansUsuario;
import modeloConexao.Conexao;

/**
 *
 * @author bbrog
 */
public class DaoUsuario {
    
    Conexao conex = new Conexao();
    ModelBeansUsuario mod = new ModelBeansUsuario();
    
    public void Salvar(ModelBeansUsuario mod){
        
        conex.conecta();
        try {
        PreparedStatement pst = conex.conexao.prepareStatement(
        "insert into bd_agenda.tb_usuario (usu_nome, usu_usuario, usu_senha, usu_tipo) values (?,?,?,?)");
        pst.setString(1, mod.getUsu_nome());
        pst.setString(2, mod.getUsu_usuario());
        pst.setString(3, mod.getUsu_senha());
        pst.setString(4, mod.getUsu_tipo());
        pst.execute();
            JOptionPane.showMessageDialog(null, "Usuário salvo com sucesso.");
        
        } catch (SQLException ex){  
            JOptionPane.showMessageDialog(null, "Erro ao salvar dados./nErro: " + ex);
        }
        
        conex.desconecta();
        
    }
    
    public ModelBeansUsuario buscaUsuario(ModelBeansUsuario mod) {
        conex.conecta();
        conex.executeSQL("select * from tb_usuario where usu_nome like'%"+mod.getUsu_pesquisa()+"%'");
        
        try {
            conex.resultset.first();
            mod.setUsu_codigo(conex.resultset.getInt("usu_codigo"));
            mod.setUsu_nome(conex.resultset.getString("usu_nome"));
            mod.setUsu_usuario(conex.resultset.getString("usu_usuario"));
            mod.setUsu_senha(conex.resultset.getString("usu_senha"));
            mod.setUsu_tipo(conex.resultset.getString("usu_tipo"));
                   
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Usuário não cadastrado");
        }
        
        conex.desconecta();
        return mod;
    }
    
    public void Editar(ModelBeansUsuario mod){
        
        conex.conecta();
        
        try {
            PreparedStatement pst;
            pst = conex.conexao.prepareStatement(
                    "update bd_agenda.tb_usuario set usu_nome = ?, usu_usuario = ?, usu_senha = ?, usu_tipo = ? where usu_codigo = ?");
                    
            pst.setString(1, mod.getUsu_nome());
            pst.setString(2, mod.getUsu_usuario());
            pst.setString(3,mod.getUsu_senha());
            pst.setString(4, mod.getUsu_tipo());
            pst.setInt(5, mod.getUsu_codigo());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados editados com sucesso.");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao editar funcionários./nErro: " + ex);
        }
               
        conex.desconecta();  
    }
    
    public void Excluir(ModelBeansUsuario mod){
        
        conex.conecta();
        
        try {
            PreparedStatement pst;
            pst = conex.conexao.prepareStatement(
                    "delete from bd_agenda.tb_usuario where usu_codigo = ?");
                    
            pst.setInt(1, mod.getUsu_codigo());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Usuário excluído com sucesso.");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir o usuário./nErro: " + ex);
        }
        
        
        conex.desconecta();
    }
    
}