/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDAO;

import modeloConexao.Conexao;
import modeloBeans.ModelBeansClientes;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


/**
 *
 * @author bbrog
 */
public class DaoClientes {
    
    Conexao conex = new Conexao();
    ModelBeansClientes mod = new ModelBeansClientes();
    
    public void Salvar(ModelBeansClientes mod){
        
        conex.conecta();
        try {
        PreparedStatement pst = conex.conexao.prepareStatement(
        "insert into bd_agenda.tb_cliente (cli_nome, cli_datanascimento, cli_email, cli_telefone) values (?,?,?,?)");
        pst.setString(1, mod.getNome());
        pst.setString(2, mod.getDatanascimento());
        pst.setString(3, mod.getEmail());
        pst.setString(4, mod.getTelefone());

        pst.execute();
            JOptionPane.showMessageDialog(null, "Cadastro salvo com sucesso.");
        
        } catch (SQLException ex){  
            JOptionPane.showMessageDialog(null, "Erro ao salvar dados./nErro: " + ex);
        }
        
        
        conex.desconecta();
        
    }
    
    public ModelBeansClientes buscaClientes(ModelBeansClientes mod) {
        conex.conecta();
        conex.executeSQL("select * from tb_cliente where cli_nome like'%"+mod.getPesquisa()+"%'");
        
        try {
            conex.resultset.first();
            mod.setCodigo(conex.resultset.getInt("cli_codigo"));
            mod.setNome(conex.resultset.getString("cli_nome"));
            mod.setDatanascimento(conex.resultset.getString("cli_datanascimento"));
            mod.setEmail(conex.resultset.getString("cli_email"));
            mod.setTelefone(conex.resultset.getString("cli_telefone"));
                   
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Cliente não cadastrado.");
        }
        
        conex.desconecta();
        return mod;
    }
    
    public void Editar(ModelBeansClientes mod){
        
        conex.conecta();
        
        try {
            PreparedStatement pst;
            pst = conex.conexao.prepareStatement(
                    "update bd_agenda.tb_cliente set cli_nome = ?, cli_email = ?, cli_datanascimento = ?, cli_telefone = ? where cli_codigo = ?");
                    
            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getEmail());
            pst.setString(3,mod.getDatanascimento());
            pst.setString(4, mod.getTelefone());
            pst.setInt(5, mod.getCodigo());
            
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Dados editados com sucesso.");
            
        } catch (SQLException ex) {
           
            JOptionPane.showMessageDialog(null, "Erro ao editar Cliente./nErro: " + ex);
        }
               
        conex.desconecta(); 
    }
    
    public void Excluir(ModelBeansClientes mod){
        
        conex.conecta();
        
        try {
            PreparedStatement pst;
            pst = conex.conexao.prepareStatement(
                    "delete from bd_agenda.tb_cliente where cli_codigo = ?");
                    
            pst.setInt(1, mod.getCodigo());
           
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Cliente excluído com sucesso.");
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Erro ao excluir o Cliente./nErro: " + ex);
        }
        
        
        conex.desconecta();
    }
    
}
