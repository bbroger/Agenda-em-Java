/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDAO;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modeloBeans.ModelBeansAgendamento;
import modeloConexao.Conexao;

/**
 *
 * @author bbrog
 */
public class DaoAgendamento {
    
    Conexao conex = new Conexao();
    Conexao conexcliente = new Conexao();
    Conexao conexfuncionario = new Conexao();
    Conexao conexservico = new Conexao();
    
    int cliente_codigo;
    int funcionario_codigo;
    int servico_codigo;   
    
    ModelBeansAgendamento mod = new ModelBeansAgendamento();
    
  public void Agendar(ModelBeansAgendamento mod){
      
        BuscarIDCliente(mod.getCliente());
        BuscarIDFuncionario(mod.getFuncionario());
        BuscarIDServico(mod.getServico()); 
        
        conex.conecta();
        
        try {
        
        PreparedStatement pst = conex.conexao.prepareStatement(
        
        "insert into bd_agenda.tb_agenda "
                + " (ag_cliente, "
                + " ag_nome_cliente, "
                + " ag_funcionario, "
                + " ag_nome_funcionario, "
                + " ag_servico, "
                + " ag_nome_servico, "
                + " ag_data, "
                + " ag_hora) "
                + " values (?,?,?,?,?,?,?,?)");
       
        pst.setInt(1, cliente_codigo);
        pst.setString(2, mod.getCliente());
        pst.setInt(3, funcionario_codigo);
        pst.setString(4, mod.getFuncionario());
        pst.setInt(5, servico_codigo);
        pst.setString(6, mod.getServico());
        pst.setDate(7, new java.sql.Date(mod.getData().getTime()));
        pst.setString(8, mod.getHora());

        pst.execute();
            
            JOptionPane.showMessageDialog(null, "Agendamento salvo com sucesso.");
        
        } catch (SQLException ex){  
           
            JOptionPane.showMessageDialog(null, "Erro ao agendar o serviço./nErro: " + ex);
        }
        
        conex.desconecta();
        
    }
    
  public ModelBeansAgendamento buscaCliente(ModelBeansAgendamento mod) {
        
        conex.conecta();
        conex.executeSQL("select * from tb_cliente where cli_nome like'%"+mod.getCliente()+"%'");
        
        try {
            conex.resultset.first();

            mod.setCliente(conex.resultset.getString("cli_nome"));

                   
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Cliente não cadastrado.");
        }
        
        conex.desconecta();
        return mod;
    }
  
  public void BuscarIDCliente (String nomeCliente){
      
      conexcliente.conecta();
      conexcliente.executeSQL(
      
      "select * from tb_cliente where cli_nome = '"+ nomeCliente+"'");
      
        try {
            conexcliente.resultset.first();
            cliente_codigo = conexcliente.resultset.getInt("cli_codigo");
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Cliente não cadastrado." + ex);
        }
  }
  
  public void BuscarIDFuncionario (String nomeFuncionario){
      
      conexfuncionario.conecta();
      conexfuncionario.executeSQL(
      
      "select * from tb_funcionario where fun_nome = '"+ nomeFuncionario +"'");
      
        try {
            conexfuncionario.resultset.first();
            funcionario_codigo = conexfuncionario.resultset.getInt("fun_codigo");
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Funcionário não cadastrado." + ex);
        }
  }
  
  public void BuscarIDServico (String nomeServico){
      
      conexservico.conecta();
      conexservico.executeSQL(
      
      "select * from tb_servico where ser_nome = '"+ nomeServico+"'");
      
        try {
            conexservico.resultset.first();
            servico_codigo = conexservico.resultset.getInt("ser_codigo");
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Serviço não cadastrado." + ex);
        }
  }
    
  public ModelBeansAgendamento buscaFuncionario(ModelBeansAgendamento mod) {
        
      conex.conecta();
      conex.executeSQL("select * from tb_funcionario where fun_nome like'%"+mod.getFuncionario()+"%'");
        
        try {
            conex.resultset.first();

            mod.setFuncionario(conex.resultset.getString("fun_nome"));
                   
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Funcionário não cadastrado");
        }
        
        conex.desconecta();
        return mod;
        
  }
      
  public void Excluir(ModelBeansAgendamento mod){
        
        conex.conecta();
        
        try {
            PreparedStatement pst;
            pst = conex.conexao.prepareStatement(
                "delete from bd_agenda.tb_agenda where ag_codigo = ?");
                    
            pst.setInt(1, mod.getCodigo());
           
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Agendamento excluído com sucesso.");
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Erro ao excluir o agendamento./nErro: " + ex);
        }
        
        
        conex.desconecta();
    }
    
}
