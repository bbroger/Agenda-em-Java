/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDAO;

import modeloConexao.Conexao;
import modeloBeans.ModelBeansFuncionarios;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


/**
 *
 * @author bbrog
 */
public class DaoFuncionarios {
    
    Conexao conex = new Conexao();
    ModelBeansFuncionarios mod = new ModelBeansFuncionarios();
    
    public void Salvar(ModelBeansFuncionarios mod){
        
        conex.conecta();
        try {
        PreparedStatement pst = conex.conexao.prepareStatement(
        "insert into bd_agenda.tb_funcionario (fun_nome, fun_datanascimento, fun_apelido, fun_telefone, fun_profissao)values (?,?,?,?,?)");
        pst.setString(1, mod.getNome());
        pst.setString(2, mod.getDatanascimento());
        pst.setString(3, mod.getApelido());
        pst.setString(4, mod.getTelefone());
        pst.setString(5, mod.getProfissao());
        pst.execute();
            JOptionPane.showMessageDialog(null, "Cadastro salvo com sucesso.");
        
        } catch (SQLException ex){  
            JOptionPane.showMessageDialog(null, "Erro ao salvar dados./nErro: " + ex);
        }
        
        
        conex.desconecta();
        
    }
    
    public ModelBeansFuncionarios buscaFuncionarios(ModelBeansFuncionarios mod) {
        
        conex.conecta();
        conex.executeSQL("select * from tb_funcionario where fun_nome like'%"+mod.getPesquisa()+"%'");
        
        try {
            conex.resultset.first();
            mod.setCodigo(conex.resultset.getInt("fun_codigo"));
            mod.setNome(conex.resultset.getString("fun_nome"));
            mod.setDatanascimento(conex.resultset.getString("fun_datanascimento"));
            mod.setApelido(conex.resultset.getString("fun_apelido"));
            mod.setProfissao(conex.resultset.getString("fun_profissao"));
            mod.setTelefone(conex.resultset.getString("fun_telefone"));
                   
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Funcionário não cadastrado");
        }
        
        conex.desconecta();
        return mod;
    }
    
    public void Editar(ModelBeansFuncionarios mod){
        
        conex.conecta();
        
        try {
            PreparedStatement pst;
            pst = conex.conexao.prepareStatement(
                    "update bd_agenda.tb_funcionario set fun_nome = ?, fun_apelido = ?, fun_datanascimento = ?, fun_telefone = ?,fun_profissao = ? where fun_codigo = ?");
                    
            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getApelido());
            pst.setString(3,mod.getDatanascimento());
            pst.setString(4, mod.getTelefone());
            pst.setString(5, mod.getProfissao());
            pst.setInt(6, mod.getCodigo());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados editados com sucesso.");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao editar funcionários./nErro: " + ex);
        }
               
        conex.desconecta(); 
    }
    
    public void Excluir(ModelBeansFuncionarios mod){
        
        conex.conecta();
        
        try {
            PreparedStatement pst;
            pst = conex.conexao.prepareStatement(
                    "delete from bd_agenda.tb_funcionario where fun_codigo = ?");
                    
            pst.setInt(1, mod.getCodigo());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Funcionário excluído com sucesso.");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir o funcionário./nErro: " + ex);
        }
        
        
        conex.desconecta();
    }
    
}
