/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDAO;

import java.sql.SQLException;
import javax.swing.JOptionPane;
import modeloBeans.ModelBeansAgendamento;
import modeloBeans.ModelBeansRelatorios;
import modeloConexao.Conexao;

/**
 *
 * @author bbrog
 */
public class DaoRelatorios {
    
    Conexao conex = new Conexao();
    ModelBeansAgendamento model = new ModelBeansAgendamento();
    
    public ModelBeansRelatorios buscaFuncionarios(ModelBeansRelatorios mod) {
        
        conex.conecta();
        conex.executeSQL("select * from tb_agenda where ag_nome_funcionario like'%"+mod.getPesquisa()+"%'");
        
        try {
            conex.resultset.first();
            model.setCodigo(conex.resultset.getInt("ag_codigo"));
            model.setCliente(conex.resultset.getString("ag_nome_cliente"));
            model.setFuncionario(conex.resultset.getString("ag_nome_funcionario"));
            model.setServico(conex.resultset.getString("ag_servico"));
            model.setData(conex.resultset.getDate("ag_data"));
            model.setHora(conex.resultset.getString("ag_hora"));
                   
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Funcionário não cadastrado");
        }
        
        conex.desconecta();
        return mod;
        
    }
    
}
