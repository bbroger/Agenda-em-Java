/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDAO;

import modeloConexao.Conexao;
import modeloBeans.ModelBeansServicos;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author bbrog
 */
public class DaoServicos {
    
    Conexao conex = new Conexao();
    ModelBeansServicos mod = new ModelBeansServicos();
    
    public void Salvar(ModelBeansServicos mod){
        
        conex.conecta();
        try {
        PreparedStatement pst = conex.conexao.prepareStatement(
        "insert into bd_agenda.tb_servico (ser_nome, ser_preco) values (?,?)");
        pst.setString(1, mod.getNome());
        pst.setString(2, mod.getPreco());

        pst.execute();
            JOptionPane.showMessageDialog(null, "Cadastro salvo com sucesso.");
        
        } catch (SQLException ex){  
            JOptionPane.showMessageDialog(null, "Erro ao salvar dados./nErro: " + ex);
        }
        
        
        conex.desconecta();
        
    }
    
    public ModelBeansServicos buscaServicos(ModelBeansServicos mod) {
        conex.conecta();
        conex.executeSQL("select * from tb_servico where ser_nome like'%"+mod.getPesquisa()+"%'");
        
        try {
            conex.resultset.first();
            mod.setCodigo(conex.resultset.getInt("ser_codigo"));
            mod.setNome(conex.resultset.getString("ser_nome"));
            mod.setPreco(conex.resultset.getString("ser_preco"));

                   
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Serviço não cadastrado." + ex);
        }
        
        conex.desconecta();
        return mod;
    }
    
    public void Editar(ModelBeansServicos mod){
        
        conex.conecta();
        
        try {
            PreparedStatement pst;
            pst = conex.conexao.prepareStatement(
                    "update bd_agenda.tb_servico set ser_nome = ?, ser_preco = ? where ser_codigo = ?");
                    
            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getPreco());
            pst.setInt(3, mod.getCodigo());
            
            pst.execute();
           
            JOptionPane.showMessageDialog(null, "Dados editados com sucesso.");
            
        } catch (SQLException ex) {
           
            JOptionPane.showMessageDialog(null, "Erro ao editar Serviço./nErro: " + ex);
        }
               
        conex.desconecta(); 
    }
    
    public void Excluir(ModelBeansServicos mod){
        
        conex.conecta();
        
        try {
            PreparedStatement pst;
            pst = conex.conexao.prepareStatement(
                    "delete from bd_agenda.tb_servico where ser_codigo = ?");
                    
            pst.setInt(1, mod.getCodigo());
            
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Servico excluído com sucesso.");
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Erro ao excluir o serviço./nErro: " + ex);
        }
        
        
        conex.desconecta();
    }
    
}
