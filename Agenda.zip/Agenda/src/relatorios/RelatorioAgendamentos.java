package relatorios;

import java.util.HashMap;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;
import modeloConexao.Conexao;


public class RelatorioAgendamentos {
    
    Conexao con = new Conexao();
    
    public RelatorioAgendamentos() {
        
        try {
            
            con.conecta();
            con.executeSQL("select * from tb_agenda order by ag_data, ag_hora");
            
            JRResultSetDataSource jrRS = new JRResultSetDataSource(con.resultset);
            JasperPrint jasperprint = JasperFillManager.fillReport (
            
                    "C:\\Users\\bbrog\\Documents\\Agenda\\src\\relatorios\\relatorioAgendamentos.jasper", new HashMap(),jrRS);
            
            JasperViewer.viewReport(jasperprint, false);
            
        } catch (JRException ex) {
            
            JOptionPane.showMessageDialog(null,"Não foi possível gerar o relatório." + ex);
            
            System.exit(0);
        }
    }
    
    public static void main (String args[]){
        
        RelatorioAgendamentos relatorioAgendamentos = new RelatorioAgendamentos();
        
        System.exit(0);
    }
}
        