/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relatorios;

import java.util.HashMap;
import javax.swing.JOptionPane;
import modeloConexao.Conexao;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;
import modeloBeans.ModelBeansRelatorios;

/**
 *
 * @author bbrog
 */
public class RelatoriosAgendamentosFuncionario {
    
    Conexao con = new Conexao();
    ModelBeansRelatorios mod = new ModelBeansRelatorios();
    
    public RelatoriosAgendamentosFuncionario() {
        
        try {
            
            con.conecta();
            con.executeSQL("select * from tb_agenda where ag_nome_funcionario like'%"+mod.getFuncionario()+"%'");
            
            JRResultSetDataSource jrRS = new JRResultSetDataSource(con.resultset);
            JasperPrint jasperprint = JasperFillManager.fillReport (
            
                    "C:\\Users\\bbrog\\Documents\\Agenda\\src\\relatorios\\relatorioAgendamentos.jasper", new HashMap(),jrRS);
            
            JasperViewer.viewReport(jasperprint, false);
            
        } catch (JRException ex) {
            
            JOptionPane.showMessageDialog(null,"Não foi possível gerar o relatório." + ex);
            
            System.exit(0);
        }
    }
    
    public static void main (String args[]){
        
        RelatorioAgendamentos relatorioAgendamentos = new RelatorioAgendamentos();
        
        System.exit(0);
    
    }
}
