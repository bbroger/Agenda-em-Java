/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloBeans;

import java.util.Date;

/**
 *
 * @author bbrog
 */
public class ModelBeansAgendamento {

    private int codigo;
    private String cliente;
    private String funcionario;
    private String servico;
    private Date data;
    private String hora;
    private String pesquisa_agenda_funcionario;

    
    /**
     * @return the data
     */
    public Date getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(Date data) {
        this.data = data;
    }
    
    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the cliente
     */
    public String getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the funcionario
     */
    public String getFuncionario() {
        return funcionario;
    }

    /**
     * @param funcionario the funcionario to set
     */
    public void setFuncionario(String funcionario) {
        this.funcionario = funcionario;
    }

    /**
     * @return the servico
     */
    public String getServico() {
        return servico;
    }

    /**
     * @param servico the servico to set
     */
    public void setServico(String servico) {
        this.servico = servico;
    }

    /**
     * @return the hora
     */
    public String getHora() {
        return hora;
    }

    /**
     * @param hora the hora to set
     */
    public void setHora(String hora) {
        this.hora = hora;
    }

    /**
     * @return the pesquisa_agenda_funcionario
     */
    public String getPesquisa_agenda_funcionario() {
        return pesquisa_agenda_funcionario;
    }

    /**
     * @param pesquisa_agenda_funcionario the pesquisa_agenda_funcionario to set
     */
    public void setPesquisa_agenda_funcionario(String pesquisa_agenda_funcionario) {
        this.pesquisa_agenda_funcionario = pesquisa_agenda_funcionario;
    } 
}

   