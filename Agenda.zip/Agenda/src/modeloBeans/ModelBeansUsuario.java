/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloBeans;

/**
 *
 * @author bbrog
 */
public class ModelBeansUsuario {

    private int usu_codigo;
    private String usu_nome;
    private String usu_usuario;
    private String usu_senha;
    private String usu_tipo;
    private String usu_pesquisa;
    
    public String getUsu_pesquisa() {
        return usu_pesquisa;
    }

    public void setUsu_pesquisa(String usu_pesquisa) {
        this.usu_pesquisa = usu_pesquisa;
    }
    
    /**
     * @return the usu_codigo
     */
    public int getUsu_codigo() {
        return usu_codigo;
    }

    /**
     * @param usu_codigo the usu_codigo to set
     */
    public void setUsu_codigo(int usu_codigo) {
        this.usu_codigo = usu_codigo;
    }

    /**
     * @return the usu_nome
     */
    public String getUsu_nome() {
        return usu_nome;
    }

    /**
     * @param usu_nome the usu_nome to set
     */
    public void setUsu_nome(String usu_nome) {
        this.usu_nome = usu_nome;
    }

    /**
     * @return the usu_usuario
     */
    public String getUsu_usuario() {
        return usu_usuario;
    }

    /**
     * @param usu_usuario the usu_usuario to set
     */
    public void setUsu_usuario(String usu_usuario) {
        this.usu_usuario = usu_usuario;
    }

    /**
     * @return the usu_senha
     */
    public String getUsu_senha() {
        return usu_senha;
    }

    /**
     * @param usu_senha the usu_senha to set
     */
    public void setUsu_senha(String usu_senha) {
        this.usu_senha = usu_senha;
    }

    /**
     * @return the usu_tipo
     */
    public String getUsu_tipo() {
        return usu_tipo;
    }

    /**
     * @param usu_tipo the usu_tipo to set
     */
    public void setUsu_tipo(String usu_tipo) {
        this.usu_tipo = usu_tipo;
    }


}
    
    